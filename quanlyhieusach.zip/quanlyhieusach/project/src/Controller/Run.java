
package Controller;
import View.FrameLogin;
public class Run {
    public static void main(String[] args) {
          //services.cnn.connect();
          FrameLogin lg = new FrameLogin();
          lg.show();
    }
    
}
