/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author ADMIN
 */
public class Model_ChucVu {
    private String tenChucVu;
    public void setChucVu(String s)
    {
        this.tenChucVu = s;
    }
    public String getChucVu()
    {
        return this.tenChucVu;
    }
}
